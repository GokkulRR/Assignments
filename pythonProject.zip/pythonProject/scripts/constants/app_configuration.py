from dotenv import load_dotenv
import os

load_dotenv('.env')
mongo_url = os.getenv('mongo')
