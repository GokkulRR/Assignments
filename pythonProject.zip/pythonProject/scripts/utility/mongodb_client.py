from pymongo import MongoClient

intern_client = MongoClient("mongodb://intern_23:intern%40123@192.168.0.220:2717/interns_b2_23")
intern_db = intern_client.interns_b2_23
course_list = intern_db.gokkul
