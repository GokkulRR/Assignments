from pymongo import MongoClient
from scripts.constants import app_configuration

intern_client = MongoClient(app_configuration.mongo_url)
intern_db = intern_client.interns_b2_23
course_list = intern_db.gokkul
