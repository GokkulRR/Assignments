from schemas.models import Name
from scripts.utility.mongodb_client import course_list


def get_input():
    return {"Welcome to Course Registering Platform!"}

def sel_course(request: Name):
    course_list.insert_one(request.dict())
    return {"Application is created Successfully"}


def get_all():
    course = (course_list.find())
    new_course = []
    for student in course:
        del student["_id"]
        new_course.append(student)
    return new_course


def update_course(application_id: int, up_course: Name):
    course_list.update_one({"application_id": application_id}, {"$set": up_course.dict()})
    return {"Application is Updated Successfully"}


def delete_course(application_id: int):
    course_list.delete_one({"application_id": application_id})
    return {"Application is Deleted Successfully"}
