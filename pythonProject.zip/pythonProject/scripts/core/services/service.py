from fastapi import APIRouter
from schemas.models import Name, Email
from scripts.core.handlers.access import get_input, sel_course, get_all, update_course, delete_course, pipeline_agg
from scripts.core.handlers.email_handler import send_email

app = APIRouter()


@app.get("/")
def fun():
    return get_input()


@app.post("/course")
def fun(request: Name):
    return sel_course(request)


@app.get("/get_all")
def fun():
    return get_all()


@app.put("/update_course/{application_id}")
def fun(application_id: int, up_course: Name):
    return update_course(application_id, up_course)


@app.delete("/delete_course/{application_id}")
def fun(application_id: int):
    return delete_course(application_id)


@app.post("/send_email")
def fun(email: Email):
    total_value = pipeline_agg()
    return send_email(str(total_value), email)


@app.get("/total_price")
def fun():
    return pipeline_agg()
