from fastapi import FastAPI
from schemas.models import Name
from scripts.core.handlers.access import get_input,sel_course,get_all,update_course,delete_course

app = FastAPI()


@app.get("/")
def fun():
    return get_input()


@app.post("/course")
def fun(request: Name):
    return sel_course(request)


@app.get("/get_all")
def fun():
    return get_all()


@app.put("/update_course/{application_id}")
def fun(application_id: int, up_course: Name):
    return update_course(application_id, up_course)


@app.delete("/delete_course/{application_id}")
def fun(application_id: int):
    return delete_course(application_id)
